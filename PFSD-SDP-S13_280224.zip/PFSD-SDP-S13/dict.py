# Empty dictionary
my_dict = {}

# Dictionary with initial key-value pairs
fruits = {"apple": "red", "banana": "yellow", "cherry": "red"}

print(fruits)
# Add a new key-value pair
fruits["orange"] = "orange"
print(fruits)


# Modify an existing value
fruits["apple"] = "green"
print(fruits)

# Loop through keys
for key in fruits:
    print(key, fruits[key])

